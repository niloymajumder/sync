const $ = (id) => document.getElementById(id);
const REDIRECT = chrome.identity.getRedirectURL();
const SCOPES = "playlist-read-private playlist-modify-private playlist-modify-public";
let track = null, playlists = [];

const store = {
  get: (k) => chrome.storage.local.get(k),
  set: (o) => chrome.storage.local.set(o),
};

function toast(msg) {
  const t = $("toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove("show"), 2000);
}
function show(view) { ["setup", "main"].forEach((v) => $(v).classList.toggle("hidden", v !== view)); }
function stateMsg(icon, title, sub) {
  $("result").classList.add("hidden"); $("state").classList.remove("hidden");
  $("state").innerHTML = `<div class="big">${icon}</div><b>${title}</b><p class="muted">${sub || ""}</p>`;
}

// ---------- PKCE auth ----------
const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
async function login(clientId) {
  const verifier = b64url(crypto.getRandomValues(new Uint8Array(64)));
  const challenge = b64url(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)));
  const url = `https://accounts.spotify.com/authorize?${new URLSearchParams({
    client_id: clientId, response_type: "code", redirect_uri: REDIRECT, scope: SCOPES,
    code_challenge_method: "S256", code_challenge: challenge,
  })}`;
  const redirect = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
  const code = new URL(redirect).searchParams.get("code");
  if (!code) throw new Error("Authorization cancelled");
  await tokenRequest({ grant_type: "authorization_code", code, redirect_uri: REDIRECT, client_id: clientId, code_verifier: verifier });
}
async function tokenRequest(body) {
  const r = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(body),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error_description || "Token error");
  const { refresh_token } = await store.get("refresh_token");
  await store.set({ access_token: j.access_token, refresh_token: j.refresh_token || refresh_token, expires_at: Date.now() + j.expires_in * 1000 - 60000 });
}
async function getToken() {
  const s = await store.get(["access_token", "refresh_token", "expires_at", "clientId"]);
  if (s.access_token && Date.now() < s.expires_at) return s.access_token;
  if (!s.refresh_token) throw new Error("NOAUTH");
  await tokenRequest({ grant_type: "refresh_token", refresh_token: s.refresh_token, client_id: s.clientId });
  return (await store.get("access_token")).access_token;
}
async function api(path, opts = {}) {
  const r = await fetch(`https://api.spotify.com/v1${path}`, {
    ...opts, headers: { Authorization: `Bearer ${await getToken()}`, "Content-Type": "application/json" },
  });
  if (r.status === 401) { await store.set({ access_token: null }); throw new Error("NOAUTH"); }
  if (!r.ok) throw new Error(`Spotify error ${r.status}`);
  return r.status === 204 ? null : r.json();
}

// ---------- Detect song on page ----------
function scrapePage() {
  const h = location.hostname;
  const q = (s) => document.querySelector(s);
  if (h.includes("music.youtube.com")) {
    const t = q("ytmusic-player-bar .title")?.textContent;
    const a = q("ytmusic-player-bar .byline a")?.textContent;
    if (t) return { title: t, artist: a || "" };
  }
  if (h.includes("youtube.com")) {
    const t = q("h1.ytd-watch-metadata yt-formatted-string")?.textContent || q('meta[name="title"]')?.content || document.title.replace(/ - YouTube$/, "");
    const a = q("ytd-video-owner-renderer #channel-name a")?.textContent || "";
    return { title: t, artist: a };
  }
  if (h.includes("soundcloud.com")) {
    const t = q(".playbackSoundBadge__titleLink span:last-child")?.textContent || q('meta[property="og:title"]')?.content;
    const a = q(".playbackSoundBadge__lightLink")?.textContent || "";
    if (t) return { title: t, artist: a };
  }
  return { title: document.title, artist: "" };
}
function cleanQuery({ title, artist }) {
  let t = (title || "").replace(/\(.*?(official|video|audio|lyric|visualizer|hd|4k|mv|live).*?\)|\[.*?\]/gi, "")
    .replace(/\b(official (music )?video|official audio|lyrics?|lyric video|ft\.?|feat\.?)\b/gi, " ")
    .replace(/[|•]/g, " ").replace(/\s+/g, " ").trim();
  const a = (artist || "").replace(/ ?- ?Topic$|VEVO$|Official$/i, "").trim();
  if (t.includes(" - ")) { const [x, y] = t.split(" - "); return `${y} ${x}`; } // "Artist - Song"
  return a && !t.toLowerCase().includes(a.toLowerCase()) ? `${t} ${a}` : t;
}

// ---------- Main ----------
const DEFAULT_SERVER = "https://id-preview--e8af9086-a485-4de8-83d9-228eeadc5a1e.lovable.app";
async function aiPick(title, artist, items) {
  const { serverUrl } = await store.get("serverUrl");
  const base = (serverUrl || DEFAULT_SERVER).replace(/\/$/, "");
  const candidates = items.map((t, i) => ({ i, name: t.name, artists: t.artists.map((a) => a.name).join(", "), album: t.album.name, year: t.album.release_date?.slice(0, 4), ms: t.duration_ms }));
  const r = await fetch(`${base}/api/public/match`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title, artist, candidates }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `AI error ${r.status}`);
  return j;
}
async function findSong() {
  show("main");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let info = { title: "", artist: "" };
  if (tab?.url && /youtube\.com|soundcloud\.com/.test(tab.url)) {
    try { [{ result: info }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scrapePage }); }
    catch { info = { title: tab.title.replace(/ - YouTube$/, ""), artist: "" }; }
  }
  $("inTitle").value = (info.title || "").trim();
  $("inArtist").value = (info.artist || "").trim();
  if (!info.title) return stateMsg("🎧", "No song detected", "Type a title and artist above, then tap Match.");
  return matchSong();
}
async function matchSong() {
  const title = $("inTitle").value.trim(), artist = $("inArtist").value.trim();
  if (!title) return toast("Enter a title");
  $("result").classList.add("hidden"); $("state").classList.remove("hidden");
  $("state").innerHTML = `<div class="spinner"></div><p class="muted">Finding the right version…</p>`;
  const q = cleanQuery({ title, artist });
  try {
    const res = await api(`/search?type=track&limit=10&q=${encodeURIComponent(q)}`);
    const items = res.tracks.items.filter(Boolean);
    if (!items.length) return stateMsg("🚫", "Not available on Spotify", `“${q}”`);
    let pick = { index: 0, reason: "" };
    try { pick = await aiPick(title, artist, items); }
    catch (e) { pick = { index: 0, reason: `AI unavailable (${e.message}) — showing top result` }; }
    if (pick.index < 0) return stateMsg("🚫", "Not found on Spotify", pick.reason || `“${q}”`);
    track = items[pick.index] || items[0];
    $("cover").src = track.album.images[1]?.url || track.album.images[0]?.url || "";
    $("tName").textContent = track.name;
    $("tArtist").textContent = track.artists.map((a) => a.name).join(", ") + " · " + track.album.name;
    $("aiReason").textContent = pick.reason ? `✨ ${pick.confidence ? pick.confidence + " confidence · " : ""}${pick.reason}` : "";
    $("openSp").href = track.external_urls.spotify;
    await loadPlaylists();
    $("state").classList.add("hidden"); $("result").classList.remove("hidden");
  } catch (e) {
    if (e.message === "NOAUTH") return openSetup();
    stateMsg("⚠️", "Something went wrong", e.message);
  }
}
async function loadPlaylists() {
  const me = await api("/me");
  playlists = [];
  let next = "/me/playlists?limit=50";
  while (next) {
    const r = await api(next.replace("https://api.spotify.com/v1", ""));
    playlists.push(...r.items.filter((p) => p && (p.owner.id === me.id || p.collaborative)));
    next = r.next;
  }
  renderPlaylists();
}
function renderPlaylists() {
  const f = $("filter").value.toLowerCase();
  $("playlists").innerHTML = "";
  playlists.filter((p) => p.name.toLowerCase().includes(f)).forEach((p) => {
    const li = document.createElement("li");
    const img = p.images?.[0]?.url;
    li.innerHTML = `${img ? `<img src="${img}">` : `<div class="ph"></div>`}<span></span><b class="add">+</b>`;
    li.querySelector("span").textContent = p.name;
    li.onclick = async () => {
      if (li.classList.contains("done")) return;
      try {
        await api(`/playlists/${p.id}/tracks`, { method: "POST", body: JSON.stringify({ uris: [track.uri] }) });
        li.classList.add("done"); li.querySelector(".add").textContent = "✓";
        toast(`Added to ${p.name}`);
      } catch (e) { toast(e.message); }
    };
    $("playlists").appendChild(li);
  });
  if (!$("playlists").children.length) $("playlists").innerHTML = `<li class="muted">No playlists</li>`;
}

async function openSetup() {
  show("setup");
  const { clientId, refresh_token } = await store.get(["clientId", "refresh_token"]);
  $("clientId").value = clientId || "";
  $("logoutBtn").classList.toggle("hidden", !refresh_token);
}

$("redirectUri").textContent = REDIRECT;
$("redirectUri").onclick = () => { navigator.clipboard.writeText(REDIRECT); toast("Copied"); };
$("filter").oninput = renderPlaylists;
$("matchBtn").onclick = matchSong;
["inTitle", "inArtist"].forEach((id) => ($(id).onkeydown = (e) => e.key === "Enter" && matchSong()));
store.get("serverUrl").then(({ serverUrl }) => ($("serverUrl").value = serverUrl || ""));
$("serverUrl").onchange = () => store.set({ serverUrl: $("serverUrl").value.trim() });
$("settingsBtn").onclick = () => ($("setup").classList.contains("hidden") ? openSetup() : findSong());
$("logoutBtn").onclick = async () => { await chrome.storage.local.remove(["access_token", "refresh_token", "expires_at"]); toast("Disconnected"); openSetup(); };
$("connectBtn").onclick = async () => {
  const clientId = $("clientId").value.trim();
  if (!clientId) return toast("Enter your Client ID");
  await store.set({ clientId });
  try { await login(clientId); toast("Connected"); findSong(); } catch (e) { toast(e.message); }
};

(async () => {
  const { refresh_token } = await store.get("refresh_token");
  refresh_token ? findSong() : openSetup();
})();
